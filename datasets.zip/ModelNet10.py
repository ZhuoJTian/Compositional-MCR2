import torch
from torch.utils.data import Dataset
import h5py
import numpy as np
import os
import torchvision.transforms as T


class ModelNetViewDataset(Dataset):
    def __init__(self, h5_path, split="train", transform=None):
        self.transform = transform
        with h5py.File(h5_path, "r") as f:
            split_arr = f["split"][:]
            # train =0, test =1
            self.indices = np.where(split_arr == (0 if split=="train" else 1))[0]
            self.data = f["data"][self.indices].astype(np.float32) / 255.0
            self.labels = f["label"][self.indices]

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, idx):
        img = self.data[idx]   # (H,W,3)
        label = int(self.labels[idx])
        img = torch.from_numpy(img).permute(2,0,1)  # [3,H,W]
        if self.transform:
            img = self.transform(img)
        return img, label


def create_datasets(num_clients, centralized=False):
    """
    Args:
        num_clients (int): view 文件数量
        centralized (bool): 是否合并成一个 dataset
    Returns:
        centralized=True  -> (train_dataset, test_dataset)
        centralized=False -> (list_of_train_datasets, list_of_test_datasets)
    """
    h5_dir = "/projappl/project_2015015/ModelNet10_views_3x3new"

    transform = T.Compose([
        T.ToPILImage(),
        T.Grayscale(num_output_channels=1),  # 转灰度
        T.Resize((64, 64)),
        T.ToTensor()
    ])

    local_datasets_train, local_datasets_test = [], []

    all_train_data, all_train_labels = [], []
    all_test_data, all_test_labels = [], []

    for v in range(num_clients):
        h5_path = os.path.join(h5_dir, f"view_{v}.h5")
        if not os.path.exists(h5_path):
            print(f"⚠️ {h5_path} 不存在，跳过。")
            continue

        train_dataset = ModelNetViewDataset(h5_path, split="train", transform=transform)
        test_dataset  = ModelNetViewDataset(h5_path, split="test", transform=transform)

        if centralized:
            all_train_data.append(train_dataset.data)
            all_train_labels.append(train_dataset.labels)
            all_test_data.append(test_dataset.data)
            all_test_labels.append(test_dataset.labels)
        else:
            local_datasets_train.append(train_dataset)
            local_datasets_test.append(test_dataset)

    if centralized:
        # 合并 numpy
        all_train_data = np.concatenate(all_train_data, axis=0)
        all_train_labels = np.concatenate(all_train_labels, axis=0)
        all_test_data = np.concatenate(all_test_data, axis=0)
        all_test_labels = np.concatenate(all_test_labels, axis=0)

        # 用同一个类再封装一次
        train_dataset = ModelNetViewDataset.__new__(ModelNetViewDataset)
        test_dataset = ModelNetViewDataset.__new__(ModelNetViewDataset)

        train_dataset.data, train_dataset.labels = all_train_data, all_train_labels
        test_dataset.data, test_dataset.labels = all_test_data, all_test_labels
        train_dataset.transform, test_dataset.transform = transform, transform

        print(f"✅ Centralized: Train={len(train_dataset)}, Test={len(test_dataset)}")
        return train_dataset, test_dataset
    else:
        print(f"✅ Federated: {len(local_datasets_train)} clients")
        return local_datasets_train, local_datasets_test
