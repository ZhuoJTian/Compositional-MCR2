from torch.utils.data import Dataset
import numpy as np
import torch
import torchvision
import torchvision.transforms as transforms
import torchvision.transforms.functional as F

def infiniteloop(dataloader):
    while True:
        for x, y in iter(dataloader):
            yield x, y

class MyViewTransform:
    """Transform: crop a view based on specified start and size."""
    def __init__(self, view_start, view_size):
        self.view_start = view_start
        self.view_size = view_size

    def __call__(self, x):
        # Assume input is PIL Image
        top = self.view_start[1]
        left = self.view_start[0]
        height = self.view_size
        width = self.view_size
        x = F.crop(x, top=top, left=left, height=height, width=width)
        return x

class CustomTensorDataset(Dataset):
    """Dataset with transform applied to each sample."""
    def __init__(self, data, targets, transform=None):
        assert len(data) == len(targets)
        self.data = data  # numpy array
        self.targets = targets  # numpy array or list
        self.transform = transform

    def __getitem__(self, index):
        x = self.data[index]
        y = self.targets[index]
        # Convert to PIL Image
        x = torchvision.transforms.functional.to_pil_image(x)
        if self.transform:
            x = self.transform(x)
        return x, y

    def __len__(self):
        return len(self.data)

def create_datasets(num_clients, View_starts, view_size, local_dist, local_dist_test):
    """Create datasets for clients in non-IID way."""
    data_path = "./Data_Sim/"

    # CIFAR-10 dataset
    training_dataset = torchvision.datasets.CIFAR10(
        root=data_path, train=True, download=True
    )
    test_dataset = torchvision.datasets.CIFAR10(
        root=data_path, train=False, download=True
    )

    x_train = training_dataset.data
    y_train = np.array(training_dataset.targets)
    x_test = test_dataset.data
    y_test = np.array(test_dataset.targets)

    # Build indices
    sample_index_train = [np.where(y_train == c)[0].tolist() for c in range(10)]
    sample_index_test = [np.where(y_test == c)[0].tolist() for c in range(10)]

    # split training dataset according to label distribution
    # get the indices of training dataset for each client
    idx_clients_train = [[] for i in range(num_clients)]
    remained = [0 for _ in range(10)]
    for i in range(num_clients):
        index = []
        for cls in range(10):
            if local_dist[i][cls] > 0:
                for num in range(int(remained[cls]), int(remained[cls] + int(local_dist[i][cls]))):
                    index.append(int(sample_index_train[cls][num]))
                remained[cls] += int(local_dist[i][cls])
        idx_clients_train[i] = index

    # get the indices of testing dataset for each client
    idx_clients_test = [[] for i in range(num_clients)]
    remained = [0 for _ in range(10)]
    for i in range(num_clients):
        index = []
        for cls in range(10):
            if local_dist_test[i][cls] > 0:
                for num in range(int(remained[cls]), int(remained[cls] + local_dist_test[i][cls])):
                    index.append(int(sample_index_test[cls][num]))
                # remained[cls] += local_dist_test[i][cls]
        idx_clients_test[i] = index


    local_datasets_train = []
    local_datasets_test = []

    for client_id in range(num_clients):
        view_start = View_starts[client_id]

        transform = transforms.Compose([
            MyViewTransform(view_start, view_size),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])

        train_indices = idx_clients_train[client_id]
        test_indices = idx_clients_test[client_id]

        dataset_train = CustomTensorDataset(x_train[train_indices], y_train[train_indices], transform)
        dataset_test = CustomTensorDataset(x_test[test_indices], y_test[test_indices], transform)

        local_datasets_test.append(dataset_test)
        local_datasets_train.append(dataset_train)

    return local_datasets_train, local_datasets_test
