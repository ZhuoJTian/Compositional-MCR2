from torch.utils.data import Dataset
import numpy as np
import torch
import torchvision
import torchvision.transforms as transforms
import torchvision.transforms.functional as F
from torchvision.datasets import ImageNet


def infiniteloop(dataloader):
    while True:
        for x, y in iter(dataloader):
            yield x, y

class MyViewTransform:
    """Transform: crop a view based on specified start and size."""
    def __init__(self, view_start, view_size):
        self.view_start = view_start
        self.view_size = view_size

    def __call__(self, x):
        # Assume input is PIL Image
        top = self.view_start[1]
        left = self.view_start[0]
        height = self.view_size
        width = self.view_size
        x = F.crop(x, top=top, left=left, height=height, width=width)
        return x

class CustomTensorDataset(Dataset):
    """Dataset with transform applied to each sample."""
    def __init__(self, data, targets, transform=None):
        assert len(data) == len(targets)
        self.data = data  # numpy array
        self.targets = targets  # numpy array or list
        self.transform = transform

    def __getitem__(self, index):
        x = self.data[index]
        y = self.targets[index]
        # Convert to PIL Image
        x = torchvision.transforms.functional.to_pil_image(x)
        if self.transform:
            x = self.transform(x)
        return x, y

    def __len__(self):
        return len(self.data)

def create_datasets(num_clients, View_start_patch, view_size_patch, patch_size, local_dist, local_dist_test):
    """Create datasets for clients in non-IID way."""
    data_path = "./Data_Sim/"

    # CIFAR-10 dataset
    training_dataset = ImageNet(
        root=data_path, split="train", download=True
    )
    test_dataset = torchvision.datasets.CIFAR10(
        root=data_path, split="test", download=True
    )

    x_train = training_dataset.data
    y_train = np.array(training_dataset.targets)
    x_test = test_dataset.data
    y_test = np.array(test_dataset.targets)

    # Build indices
    sample_index_train = [np.where(y_train == c)[0].tolist() for c in range(10)]
    sample_index_test = [np.where(y_test == c)[0].tolist() for c in range(10)]

    # Common indices (5000 samples per class)
    idx_clients_com = []
    for _ in range(num_clients):
        idx = []
        for cls in range(10):
            idx.extend(sample_index_train[cls][:5000])
        idx_clients_com.append(idx)

    # Test indices
    idx_clients_test = []
    for i in range(num_clients):
        idx = []
        for cls in range(10):
            if local_dist_test[i][cls] > 0:
                idx.extend(sample_index_test[cls][:int(local_dist_test[i][cls])])
        idx_clients_test.append(idx)

    local_datasets_train = []
    local_datasets_com = []
    local_datasets_test = []

    for client_id in range(num_clients):
        View_start_patchi = View_start_patch[client_id]
        view_start = [View_start_patchi[0] * patch_size, View_start_patchi[1] * patch_size]
        view_size = view_size_patch * patch_size

        transform = transforms.Compose([
            MyViewTransform(view_start, view_size),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])

        com_indices = idx_clients_com[client_id]
        test_indices = idx_clients_test[client_id]

        dataset_com = CustomTensorDataset(x_train[com_indices], y_train[com_indices], transform)
        dataset_test = CustomTensorDataset(x_test[test_indices], y_test[test_indices], transform)

        local_datasets_com.append(dataset_com)
        local_datasets_test.append(dataset_test)
        local_datasets_train.append([])  # No local train set in your logic

    # Expert set without cropping view
    expert_transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
    ])
    expert_com = CustomTensorDataset(
        x_train[idx_clients_com[0]],
        y_train[idx_clients_com[0]],
        expert_transform
    )

    return local_datasets_train, local_datasets_com, local_datasets_test, expert_com
